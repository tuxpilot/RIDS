<?php
/**
 * Envoie un SMS puis affiche la liste des SMS en attente d’envoi.
 * 
 * pour générer les clés d'accès API pour:
 *
 * GET /sms
 #*/

$sms_number = $argv[1];
$sms_message = $argv[2];

require __DIR__ . '/vendor/autoload.php';
use \Ovh\Api;

$endpoint = 'ovh-eu';
$applicationKey = "";
$applicationSecret = "";
$consumer_key = "";

$conn = new Api(    $applicationKey,
                    $applicationSecret,
                    $endpoint,
                    $consumer_key);

$smsServices = $conn->get('/sms/');
foreach ($smsServices as $smsService) {

    print_r($smsService);
}

$content = (object) array(
    "charset"=> "UTF-8",
    "class"=> "phoneDisplay",
    "coding"=> "7bit",
    "message"=> $sms_message,
    "noStopClause"=> false,
    "priority"=> "high",
    "receivers"=> [ $sms_number ],
    "senderForResponse"=> true,
    "validityPeriod"=> 2880
);
$resultPostJob = $conn->post('/sms/'. $smsServices[0] . '/jobs', $content);

print_r($resultPostJob);

$smsJobs = $conn->get('/sms/'. $smsServices[0] . '/jobs');
print_r($smsJobs);

?>
